package base;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import initiate.PropertiesReader;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public abstract class Base {

    public static Properties prop ;
    public static WebDriver driver ;
    public static WebDriver intializEDriver()throws IOException {

        prop = new Properties();
        String propPath = System.getProperty("user.dir")+ "\\Configuration\\data.properties";
        FileInputStream file = new FileInputStream(propPath);
        prop.load(file );
        String BrowserName = prop.getProperty("browser");
        if (BrowserName.equalsIgnoreCase("chrome")) {
            WebDriverManager.chromedriver().setup();
            driver = new ChromeDriver(); }
        else if (BrowserName.equalsIgnoreCase("fireFox")) {
            WebDriverManager.firefoxdriver().setup();
            driver = new FirefoxDriver(); }
        else if (BrowserName.equalsIgnoreCase("Edge")) {
            WebDriverManager.edgedriver().setup();
            driver = new EdgeDriver();}
        else if (BrowserName.equalsIgnoreCase("IE")) {
            WebDriverManager.iedriver().setup();
            driver = new InternetExplorerDriver();
        }



        driver.manage().window().maximize();
        driver.navigate().to(PropertiesReader.ReadData("Testurl"));
        return driver;
    }


    public static WebDriver intializEDriverMain()throws IOException {

        prop = new Properties();
        String propPath = System.getProperty("user.dir")+ "\\Configuration\\data.properties";
        FileInputStream file = new FileInputStream(propPath);
        prop.load(file );
        String BrowserName = prop.getProperty("browser");
        if (BrowserName.equalsIgnoreCase("chrome")) {
            WebDriverManager.chromedriver().setup();
            driver = new ChromeDriver(); }
        else if (BrowserName.equalsIgnoreCase("fireFox")) {
            WebDriverManager.firefoxdriver().setup();
            driver = new FirefoxDriver(); }
        else if (BrowserName.equalsIgnoreCase("Edge")) {
            WebDriverManager.edgedriver().setup();
            driver = new EdgeDriver();}
        else if (BrowserName.equalsIgnoreCase("IE")) {
            WebDriverManager.iedriver().setup();
            driver = new InternetExplorerDriver();
        }



        driver.manage().window().maximize();
        driver.navigate().to(PropertiesReader.ReadData("Test"));
        return driver;
    }
    public abstract boolean switchToFrameByIndex(WebDriver driver, int index);

    public abstract void explicitWait(WebDriver driver, WebElement element, int timeOut);
}
