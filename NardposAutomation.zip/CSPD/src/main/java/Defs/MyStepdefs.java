package Defs;

import actiondriver.Action;
import base.Base;
import cartpageobject.CartPageObject;
import com.github.javafaker.Bool;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import registerpageobject.RegisterPage;
import registertest.RegisterTest;

import java.io.IOException;
import java.util.Random;

public class MyStepdefs extends Base {
    Random rand = new Random();
    int rnd = rand.nextInt(999) + 1;
    @Given("Go  to test Link")
    public void go_to_test_link() throws IOException {
        Base.intializEDriver();
     //   throw new io.cucumber.java.PendingException();
    }

    @When("Register using valid data")
    public void register_using_valid_data() throws Throwable {
        RegisterPage registerPage = new RegisterPage(driver);
        String Firstname = prop.getProperty("Firstname");
        String Lastname =prop.getProperty("Lastname");
        String Email = "Test+"+rnd+"@test.com";
        String Password = prop.getProperty("Password");
        String Password1 = prop.getProperty("Password1");
        registerPage.RegisterValidData(Firstname,Lastname,Email,Password,Password1);
        Thread.sleep(2500);

      //  RegisterPage.Date();

    }

    @Then("This context Your registration completed should be displyed")
    public void this_context_your_registration_completed_should_be_displyed() {
   String ActualResult = ("nopCommerce demo store. Register");
   String ExcpectedResult = driver.getTitle();
        Assert.assertEquals(ExcpectedResult,ActualResult);
        driver.close();
    }
    @When("Register using Invalid data")
    public void register_using_invalid_data() throws Throwable {
        RegisterPage registerPage = new RegisterPage(driver);
        String Firstname = prop.getProperty("Firstname");
        String Lastname =prop.getProperty("Lastname");
        String Email = "test";
        String Password = prop.getProperty("Password");
        String Password1 = prop.getProperty("Password1");
        registerPage.RegisterInValidData(Firstname,Lastname,Email,Password,Password1);
        Thread.sleep(2500);
    }
    @Then("This context Wrong email should be displayed")
    public void this_context_wrong_email_should_be_displayed() {
       String page =  driver.getPageSource();

    boolean x =  page.contains("Wrong email");
    if (x==true)
     System.out.println(x+"The hint is displayed");
    else      System.out.println(x+"The hint is not displayed");
    driver.close();

    }
    @Given("Go  to main page")
    public void go_to_main_page() throws IOException {
        Base.intializEDriverMain();
    }
    @When("Search about item like HTC")
    public void search_about_item_like_htc() {
        CartPageObject cartPageObject = new CartPageObject(driver);
        String searchtext = prop.getProperty("searchtxt");
        CartPageObject.search(searchtext);
    }

    @Then("Add item to the cart")
    public void add_item_to_the_cart() {
        CartPageObject cartPageObject = new CartPageObject(driver);
        CartPageObject.addtocart();
        String ActualResult = ("The product has been added to your shopping cart");
        String ExcpectedResult = driver.getPageSource();
        Assert.assertEquals(ExcpectedResult.contains("The product has been added to your shopping cart"),ActualResult);
        driver.close();
    }

    @Override
    public boolean switchToFrameByIndex(WebDriver driver, int index) {
        return false;
    }

    @Override
    public void explicitWait(WebDriver driver, WebElement element, int timeOut) {

    }
}
