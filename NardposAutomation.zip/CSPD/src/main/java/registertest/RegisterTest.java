package registertest;

import actiondriver.Action;
import base.Base;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import registerpageobject.RegisterPage;

import java.io.IOException;

public class RegisterTest extends Base {
    public static WebDriver driver;
    Action action = new Action();




    @BeforeClass()
    public void openPage() throws IOException {
        driver = intializEDriver();
        driver.get(prop.getProperty("url"));
    }
    @AfterClass()
    public void closure() {
        //  driver.quit();

    }
    @Test
    public static void loginTest() throws Throwable {
        RegisterPage registerPage = new RegisterPage(driver);
        String Firstname = prop.getProperty("Firstname");
        String password = prop.getProperty("password");
    }


        @Override
    public boolean switchToFrameByIndex(WebDriver driver, int index) {
        return false;
    }

    @Override
    public void explicitWait(WebDriver driver, WebElement element, int timeOut) {

    }
}
