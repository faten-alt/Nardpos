package registerpageobject;

import actiondriver.Action;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.python.antlr.ast.Str;
import org.testng.annotations.Test;

import java.util.List;

public class RegisterPage {
    public static WebDriver driver;
    static Action action = new Action();
    @FindBy (xpath = "//a[.='Register']/@href")
    private static WebElement register_button ;
    @FindBy (xpath = "//input[@id='FirstName']")
     private static WebElement FirstName;
    @FindBy(xpath = "//*[@id=\"LastName\"]")
    private static WebElement LastName;

    @FindBy (xpath = "//div[@class='date-picker-wrapper']/select[@name='DateOfBirthDay']/option")
    private static List<WebElement> day;
    @FindBy(xpath = "//div[@class='date-picker-wrapper']/select[@name='DateOfBirthDay']")
    private static WebElement day1;
    @FindBy (xpath = "//div[@class='date-picker-wrapper']/select[@name='DateOfBirthYear']/option")
    private static List<WebElement> year ;
    @FindBy (xpath = "//div[@class='date-picker-wrapper']/select[@name='DateOfBirthYear']")
    private static  WebElement year1 ;
    @FindBy (xpath = "//div[@class='date-picker-wrapper']/select[@name='DateOfBirthMonth']/option")
    private static List<WebElement> month ;
    @FindBy (xpath = "//div[@class='date-picker-wrapper']/select[@name='DateOfBirthMonth']")
    private static WebElement month1 ;
    @FindBy (id = "Email")
    private static WebElement email ;
    @FindBy (xpath = "//input[@id='Password']")
    private static WebElement password;
    @FindBy(xpath = "//input[@id='ConfirmPassword']")
    private static WebElement password1;
    @FindBy(xpath = "//button[@id='register-button']")
    private static WebElement RegisterButton;
    public RegisterPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }


    public static  void RegisterValidData(String firstname , String lastname, String Email, String pswd , String pswd1)
            throws Throwable {
        Thread.sleep(6000);
        action.typestring(FirstName,firstname);
        action.typestring(LastName,lastname);
        action.click(driver , day1);
        for (int i = 0; i < day.size()-25; i++) {
            day.get(i).click();}
       action.click(driver,month1);
        for (int i = 0; i < month.size()-5; i++) {
            month.get(i).click();}
        action.click(driver,year1);
        for (int i = 0; i < year.size()-100; i++) {
            year.get(i).click();}
        action.typestring(email,  Email);
        action.scrollByVisibilityOfElement(driver,password);
        action.typestring(password,pswd);
        action.typestring(password1,pswd1);
        action.click(driver,RegisterButton);
    }

    public static  void RegisterInValidData(String firstname , String lastname, String Email, String pswd , String pswd1)
            throws Throwable {
        Thread.sleep(6000);
        action.typestring(FirstName,firstname);
        action.typestring(LastName,lastname);
        action.click(driver , day1);
        for (int i = 0; i < day.size()-25; i++) {
            day.get(i).click();}
        action.click(driver,month1);
        for (int i = 0; i < month.size()-5; i++) {
            month.get(i).click();}
        action.click(driver,year1);
        for (int i = 0; i < year.size()-100; i++) {
            year.get(i).click();}
        action.typestring(email,  Email);
        action.scrollByVisibilityOfElement(driver,password);
        action.typestring(password,pswd);
        action.typestring(password1,pswd1);
        action.click(driver,RegisterButton);
    }

}
