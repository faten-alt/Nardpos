package cartpageobject;

import actiondriver.Action;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CartPageObject {
    public static WebDriver driver;
    static Action action = new Action();
    @FindBy(xpath = "//input[@placeholder='Search store']")
    private static WebElement searchfield;
    @FindBy(xpath = "//button[@class='button-1 search-box-button']")
    private static WebElement searchbtn;
    @FindBy(xpath = "//button[@class='button-2 product-box-add-to-cart-button']")
    private static WebElement AddtoCart;

    public CartPageObject(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public static  void search(String searchtxt) {
        action.typestring(searchfield,searchtxt);
        action.click(driver,searchbtn);
        action.scrollByVisibilityOfElement(driver,AddtoCart);
    }
    public static void addtocart () {
        action.click(driver,AddtoCart);
    }
}
